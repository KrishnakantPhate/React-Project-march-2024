import axios from 'axios';
 
export let dataSericeObj =
{
    getAllDepartments,
    addDept,
    deleteDept,
    getDeptById,
    updateDept
};
 
let url = "http://localhost:3500/login/";
export let dataServiceobj ={
    getdata,
    createData,
    deleteData,
    selectData,
    updateData
};

let url1 = "http://localhost:3500/products/";
function createData(userObj){
    return axios.post(url1 , userObj);
}
function getdata(){
    return axios.get(url1);
}
function deleteData(dId){
    return axios.delete(url1 + dId);
}
 
function selectData(dId){
    return axios.get(url1 + dId);
}
 
function updateData(dataObj , dId){
    return axios.put(url1 + dId , dataObj);
}
 
function getAllDepartments()
{
    return axios.get(url);
}
 
function addDept(deptObj)
{
    return axios.post(url, deptObj);
}
 
function deleteDept(dno)
{
    return axios.delete(url + dno);
}
 
function getDeptById(dno)
{
    return axios.get(url + dno);
}
 
function updateDept(dno,deptObj){
    return axios.put(url + dno , deptObj);
}