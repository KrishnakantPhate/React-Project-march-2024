import React from "react";
import { Context } from "./context/context";
import { Route, Routes, useNavigate } from "react-router-dom";
import { HomePage } from "./pages/HomePage";
import { ProductOverView } from "./pages/ProductOverView";
import { Header } from "./components/header/Header";
import { Footer } from "./components/footer/Footer";
import { BtnScroll } from "./components/btn-scroll/BtnScroll";
import Login from "./components/login.component";
import SignUp from "./components/signup.component";
import Product from "./components/product";
import PaymentForm from "./components/paymentForm";
import ThankYouPage from "./components/thanks";

export default function App() {
  const navigate = useNavigate();
  const productId = { id: 0 };

  const isLoginPage = () => {
    return ['/', '/sign-in', '/sign-up'].includes(window.location.pathname);
  };

  return (
    <main>
      <Context.Provider value={productId}>
        {!isLoginPage() && <Header />}
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/sign-up" element={<SignUp />} />
          <Route path="/payment" element={<PaymentForm />} />
          <Route path="/thanks" element={<ThankYouPage />} />
          <Route path="/admin" element={<Product />} />
          <Route path="/sign-in" element={<Login />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/products/:id" element={<ProductOverView />} />
        </Routes>
        {!isLoginPage() && <BtnScroll />}
        {!isLoginPage() && <Footer />}
      </Context.Provider>
    </main>
  );
}