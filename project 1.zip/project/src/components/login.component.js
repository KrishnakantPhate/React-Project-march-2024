import React, { Component } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useHistory } from 'react-router-dom';
import axios from 'axios';
import './login.css';

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      error: ''
    };
  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleSubmit = async (event) => {
    event.preventDefault();
    const { email, password } = this.state;

    try {
      // You need to replace 'your-api-endpoint' with the actual endpoint of your server
    //   const response = await axios.post('http://localhost:3500/login/', { email, password });
    //   // Assuming your server returns a success message upon successful login
    //   if (response.data.success) {
    //     // Redirect to the homepage upon successful login
    //     this.props.history.push('/homepage');
    //   } else {
    //     alert("Invalid Email/Password !!");
    //   }
    const response = await axios.get('http://localhost:3500/login/');

    const user = response.data.find(user => user.email === email && user.password === password);

    if (user) {
      if (email === 'admin@g.c' && password === 'admin') {
        window.location.href = '/admin';
      } else {
        window.location.href = '/home';
      }
    } else {
        alert("Invalid Email/Password !!");
    }
    } catch (error) {
      console.error('Error:', error);
      this.setState({ error: 'An error occurred while processing your request' });
    }
  };

  render() {
    return (
      <div className="login-container">
        <header>
          <div className="App">
            <nav className="navbar navbar-expand-lg navbar-dark fixed-top">
              <div className="container">
                <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
                  <ul className="navbar-nav ml-auto">
                    <li className="nav-item">
                      <Link className="nav-link" to={'/sign-in'}>
                        Login
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" to={'/sign-up'}>
                        Sign up
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
        </header>
        <form className="login-form" onSubmit={this.handleSubmit}>
          <h3>Sign In</h3>
 
          <div className="mb-3">
            <label>Email address</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter email"
              name="email"
              value={this.state.email}
              onChange={this.handleChange}
              required
            />
          </div>
 
          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
              required
            />
          </div>
 
          <div className="d-grid">
            <button type="submit">
              Submit
            </button>
          </div>
          {this.state.error && <p className="error-message">{this.state.error}</p>}
        </form>
      </div>
    );
  }
}