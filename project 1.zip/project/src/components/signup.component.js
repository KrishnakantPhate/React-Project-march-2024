import React, { Component } from 'react';
import { dataSericeObj } from '../services/dataService';
import { withRouter } from 'react-router-dom';
import './signUp.css'; // Import the CSS file
 
export default class SignUp extends Component {
  constructor(props) {
    super(props);
 
    this.state = {  
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      isEmailValid: true, // Track email validation status
    };
  }
 
  handleInputChange = (event) => {
    const { name, value } = event.target;
 
    this.setState({
      [name]: value,
    });
  };
 
  validateEmail = (email) => {
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
 
  handleSubmit = async (event) => {
    event.preventDefault();
 
    const { firstName, lastName, email, password } = this.state;
 
    // Validate email format
    const isEmailValid = this.validateEmail(email);
 
    if (!isEmailValid) {
      this.setState({
        isEmailValid: false,
      });
      return;
    }
 
    let deptObj = { };
 
    deptObj.first_name = firstName;
    deptObj.last_name = lastName;
    deptObj.email = email;
    deptObj.password = password;
 
    try {
      // Call the addDept function to register the user
      dataSericeObj.addDept(deptObj).then(resData => {
        alert("New Account Created Successfully !!");
        // Redirect to sign-in page
        window.location.href = '/sign-in';
      });
 
    } catch (error) {
      // Handle registration error (e.g., display an error message)
      console.error('Error registering user:', error);
    }
 
    console.log('Form submitted:', { firstName, lastName, email, password });
  };
 
  render() {
    const { isEmailValid } = this.state;
 
    return (
      <div className="sign-up-container">
        <form className="sign-up-form" onSubmit={this.handleSubmit}>
          <h3>Sign Up</h3>
 
          <div className="mb-3">
            <label>First name</label>
            <input
              type="text"
              className="form-control"
              name="firstName"
              placeholder="First name"
              onChange={this.handleInputChange}
              required
            />
          </div>
 
          <div className="mb-3">
            <label>Last name</label>
            <input
              type="text"
              className="form-control"
              name="lastName"
              placeholder="Last name"
              onChange={this.handleInputChange}
              required
            />
          </div>
 
          <div className="mb-3">
            <label>Email address</label>
            <input
              type="email"
              className={`form-control ${isEmailValid ? '' : 'is-invalid'}`}
              name="email"
              placeholder="Enter email"
              onChange={this.handleInputChange}
              required
            />
            {!isEmailValid && <div className="invalid-feedback">Invalid email format</div>}
          </div>
 
          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              name="password"
              placeholder="Enter password"
              onChange={this.handleInputChange}
              required
            />
          </div>
 
          <div className="d-grid">
            <button type="submit" className="btn">
              Sign Up
            </button>
          </div>
          <p className="forgot-password text-right">
            Already registered <a href="/sign-in">sign in?</a>
          </p>
        </form>
      </div>
    );
  }
}
 