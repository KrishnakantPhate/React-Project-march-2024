import { useState } from "react";
import { dataServiceobj } from "../services/dataService";
import './product.css';

function Product() {
    let url = "http://localhost:3500/products/";
    const [usersArray, setusersArray] = useState([]);
    const [id, setId] = useState([]);
    const [title, setTitle] = useState([]);
    const [price, setprice] = useState([]);
    const [description, setDescription] = useState([]);
    const [category, setCategory] = useState([]);
    const [image, setImg] = useState([]);
    // const [rate , setRate] = useState([]);
    // const [count , setCount] = useState([]);
    // const [rating , setRating] = useState({rate:" ", count:" " });



    const [getId, setId1] = useState([]);

    function buttonClick() {

        let getobj = dataServiceobj.getdata();
        getobj.then(resData => {
            setusersArray(resData.data);
        });

    }
    function clearFeilds() {

        setId("");
        setTitle("");
        setprice("");
        setDescription("");
        setCategory("");
        setImg("");
        // setRate("");
        // setCount("");
    }

    function updateUser() {
        let userObj = {};
        let dno = getId;
        userObj.title = title;
        userObj.price = price;
        userObj.description = description;
        userObj.category = category;
        userObj.image = image;
        // userObj.rating.rate = rating.rate;
        // userObj.rating.count = rating.count;


        dataServiceobj.updateData(userObj, dno).then(resData => {
            buttonClick();
            clearFeilds();
        })
        setId1("");
    }

    function addUser() {
        let userObj = {};
        userObj.id = id;
        userObj.title = title;
        userObj.price = price;
        userObj.description = description;
        userObj.category = category;
        userObj.image = image;
        // userObj.rating[rate] = rating.rate;
        // userObj.rate = rating[rate];
        // userObj.count = rating.count;


        let createobj = dataServiceobj.createData(userObj);
        createobj.then(reqData => {
            buttonClick();
            clearFeilds();
        });

    }

    function deleteData(id) {
        dataServiceobj.deleteData(id).then(reqData => {
            buttonClick();
        });
    }

    function selectData(id) {
        dataServiceobj.selectData(id).then(resData => {
            let dataObj = resData.data;
            setId(dataObj.id);
            setTitle(dataObj.title);
            setprice(dataObj.price);
            setDescription(dataObj.description);
            setCategory(dataObj.category);
            setImg(dataObj.image);
            // setRate(dataObj.rate);
            // setCount(dataObj.count);


        })

        setId1(id);

    }

    var result = usersArray.map((item, index) => {
        return (

            <tr>
                <td className="td">{item.id}</td>
                <td className="td">{item.title}</td>
                <td className="td">{item.price}</td>
                <td className="td">{item.description}</td>
                <td className="td">{item.category}</td>

                {/* <td>{item.rating}</td> */}
                <td><img style={{ width: 100 }} src={item.image}></img></td>
                <td><a href="#" onClick={() => selectData(item.id)}>Select</a> <a href="#" className="fa fa-trash" onClick={() => deleteData(item.id)}>Delete</a></td>
            </tr>


        )
    })

    return (

        <>
            <div className="content">

                <h1 align='center'>Product Details</h1>


                <div className="input">
                    <input type="text" placeholder="Id" value={id} onChange={(e) => setId(e.target.value)}></input>
                    <input type="text" placeholder="title" value={title} onChange={(e) => setTitle(e.target.value)}></input>
                    <input type="text" placeholder="price" value={price} onChange={(e) => setprice(e.target.value)}></input>
                    <input type="text" placeholder="description" value={description} onChange={(e) => setDescription(e.target.value)}></input>
                    <input type="text" placeholder="description" value={category} onChange={(e) => setCategory(e.target.value)}></input>

                    {/* <label for="cars">Choose Category:</label> */}

                    {/* <select placeholder="category" value={category} onChange={(e) => setCategory(e.target.value)}>
                        <option >HeadPhone</option>
                        <option >Earphone</option>
                        <option >Earbud</option>
                        <option >Speaker</option>
                    </select> */}

                    {/* <input type="text" placeholder="category" value={category} onChange={(e) => setCategory(e.target.value)}></input> */}
                    <input type="text" placeholder="Image url" value={image} onChange={(e) => setImg(e.target.value)}></input> <br></br>
                    {/* <input type="text" placeholder="Rating" value={rating} onChange={(e) => setRating(e.target.value)}></input> */}

                    <br />

                </div>


                <div className="newButton button">

                    <button type="button" onClick={buttonClick} >Get Data</button>  <span></span>
                    <button type="button" onClick={addUser}>Add Data</button> <span></span>
                    <button type="button" onClick={updateUser}>Update</button> <span></span>
                    <br />
                    <br />
                    <hr />

                </div>


                <table width="800" border="2" className="table">
                    <tr>
                        <th >Id</th>
                        <th >Title</th>
                        <th >Price</th>
                        <th >Description</th>
                        <th >category</th>
                        <th >Image</th>
                        <th>Action</th>
                        {/* <th>Rate</th>
                <th>Count</th> */}
                    </tr>
                    {result}
                </table>
            </div>

        </>
    );
}

export default Product;