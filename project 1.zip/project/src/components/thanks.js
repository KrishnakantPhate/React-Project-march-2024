import React from 'react';
import './thankcss.css';
 
function ThankYouPage() {
    return (
        <div className="thank-you-page">
            <h1>Thank You!</h1>
            <p>Your order has been placed successfully.</p>
            {/* You can add additional content or styling here */}
        </div>
    );
}
 
export default ThankYouPage;