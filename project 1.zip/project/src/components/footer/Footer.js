import React from "react"
 
export function Footer() {
    return (
        <footer className='bg-[#2c98c3] text-white'>
            <div className='max-w-[1240px] mx-auto py-2 text-sm sm:text-base'>
                <div className='flex justify-center'>
                   
                </div>
                <div className='flex justify-center flex-col items-center'>
                    <p className='text-center'>React JS Project</p>
                    <a className='hover:text-gray-300 transition'>
                        Created by Group - 1
                    </a>
                </div>
            </div>
        </footer>
    )
}