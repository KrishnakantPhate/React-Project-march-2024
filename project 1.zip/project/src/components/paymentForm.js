import React from 'react';
import './payment.css';
 
function PaymentForm() {
  // Function to format card number with hyphens
//   const formatCardNumber = (input) => {
//     let cardNumber = input.value.replace(/\D/g, '');
//     if (cardNumber.length > 4) {
//       cardNumber = cardNumber.match(/.{1,4}/g).join('-');
//     }
//     input.value = cardNumber;
//   };
 
  // Function to validate form fields and redirect to Thanks page
//   const checkForm = () => {
//     const form = document.forms['paymentForm'];
//     let fieldsMustBeFilled = true;
 
//     for (let i = 0; i < form.length; i++) {
//       if (form[i].value.length === 0) {
//         fieldsMustBeFilled = false;
//         break;
//       }
//     }
 
//     if (fieldsMustBeFilled) {
//       // Redirect to Thanks page
//       window.location.href = '/Thanks';
//     } else {
//       // Enable checkout button if any field is empty
//       document.getElementById("checkoutBtn").disabled = false;
//     }
//   };

function thanksPage() {
    console.log("hello")
    window.location.href = '/thanks';
}
 
  return (
    <>
   
    <div className="container1 containerfinal">
 
        <div class="row">
 
            <div class="col">
                <h3 class="title">
                    Billing Address
                </h3>
 
                <div class="inputBox1">
                    <label className='labale1' for="name">
                        Full Name:
                    </label>
                    <input type="text" id="name"
                           placeholder="Enter your full name"
                           required/>
                </div>
 
                <div class="inputBox">
                    <label className='labale1' for="email">
                        Email:
                    </label>
                    <input type="text" id="email"
                           placeholder="Enter email address"
                           required/>
                </div>
 
                <div class="inputBox">
                    <label className='labale1' for="address">
                        Address:
                    </label>
                    <input type="text" id="address"
                           placeholder="Enter address"
                           required/>
                </div>
 
                <div class="inputBox">
                    <label className='labale1' for="city">
                        City:
                    </label>
                    <input type="text" id="city"
                           placeholder="Enter city"
                           required/>
                </div>
 
                <div class="flex">
 
                    <div class="inputBox">
                        <label className='labale1' for="state">
                            State:
                        </label>
                        <input type="text" id="state"
                               placeholder="Enter state"
                               required/>
                    </div>
 
                    <div class="inputBox">
                        <label className='labale1' for="zip">
                            Zip Code:
                        </label>
                        <input type="number" id="zip"
                               placeholder="12345"
                               required/>
                    </div>
 
                </div>
 
            </div>
            <div class="col">
                <h3 class="title">Payment</h3>
               
                <div id="cardPaymentDetails">
                    <div class="inputBox">
                        <label className='labale1' for="name">
                            Card Accepted:
                        </label>
                        <img className='img1' width={1200} height={100} src="https://tse2.mm.bing.net/th/id/OIP.7Fn4SknO8-wynHqbgQ41dgAAAA?rs=1&pid=ImgDetMain"
                             alt="credit/debit card image"/>
                    </div>
 
                    <div class="inputBox">
                        <label className='labale1' for="cardName">
                            Name On Card:
                        </label>
                        <input type="text" id="cardName"
                               placeholder="Enter card name"
                               required/>
                    </div>
 
                    <div class="inputBox">
                        <label className='labale1' for="cardNumber">
                            Credit Card Number:
                        </label>
                        <input type="text"  id="cardNumber"
                               placeholder="1111-2222-3333-4444"
                               maxlength="19" required
                               />
                    </div>
 
                    <div class="inputBox" required>
 
                        <label className='labale1' for="">Exp Month:</label>
                        <select name="" id="" required>
                            <option value="">Choose month</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                        </select>
                    </div>
 
 
                    <div class="flex">
                        <div class="inputBox">
                            <label className='labale1' for="">Exp Year:</label>
                            <select name="" id="" required>
                                <option value="">Choose Year</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                            </select>
                        </div>
 
                        <div class="inputBox">
                            <label className='labale1' for="cvv">CVV</label>
                            <input type="number" id="cvv"
                                   placeholder="1234" required/>
                        </div>
                    </div>
                    </div>
                </div>
 
            </div>
 
{/* @*               <input  type="submit" onclick="location.href='@Url.Action("Index" , "Home/Thanks")'" value="Proceed to Checkout" class="submit_btn" id="checkoutBtn">
              <input type="submit" onclick="checkform()" value="Proceed to Checkout" class="submit_btn" id="checkoutBtn">
       @* <input type="submit" onclick="Location.href='@Url.Action("Index.cshtml" , "thanks.cshtml")'" value="Proceed to checkout" />*@ */}
                     <button type="submit" className=" submit_btn" onClick={thanksPage}>
              Proceed to Checkout
            </button>
 
</div> </>
  );
}
 
export default PaymentForm;